# PokeAchieve Tracker GUI
# Cross-platform achievement tracker for Pokemon games via RetroArch

from .tracker_gui import main

__version__ = "1.2"
__all__ = ["main"]
